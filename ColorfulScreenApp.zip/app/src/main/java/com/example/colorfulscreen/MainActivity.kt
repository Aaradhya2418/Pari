package com.example.colorfulscreen

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import androidx.appcompat.app.AppCompatActivity
import android.widget.LinearLayout
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val mainLayout = findViewById<LinearLayout>(R.id.mainLayout)
        val handler = Handler()

        val changeColor = object : Runnable {
            override fun run() {
                val randomColor = Color.rgb(Random.nextInt(256), Random.nextInt(256), Random.nextInt(256))
                mainLayout.setBackgroundColor(randomColor)
                handler.postDelayed(this, 500) // Change color every 500ms
            }
        }
        handler.post(changeColor)
    }
}
